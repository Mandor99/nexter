"use strict";var test=20;
//# sourceMappingURL=index.js.map
